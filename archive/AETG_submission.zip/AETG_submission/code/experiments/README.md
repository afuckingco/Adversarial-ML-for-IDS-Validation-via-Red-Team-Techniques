# experiments/ — Notes

## `eval_results.json` — Mini-SOC ML detector evaluation
200 benign + 200 adversarial C2 beacon flows, evaluated with the XGBoost detector
(`shared/model/xgb_model.json` + scaler). This is a real model evaluation (sklearn),
not a simulation.

- recall = 1.0, evasion_rate = 0.0, precision = 0.5, f1 = 0.667, auc = 0.505
- `alert_count_in_redis = 5` — value after the `eval_ids.py` key-pattern fix
  (script now scans `alert:*` keys via `r.keys()`).

## `adv_training_results.json` — SUPPLEMENTARY / PRELIMINARY
These adversarial-training results are **not part of the reported paper results**.
The paper lists adversarial training only as future work (Section 6). This file holds
a preliminary run of `adv_training.py`, kept for reproducibility traceability only:

- Baseline: evasion_rate = 1.0, recall = 0.0
- Adversarially trained: evasion_rate = 0.089, recall = 0.911, f1 = 0.953
- Train: 210 benign + 210 adversarial; Test: 90 benign + 90 adversarial

Do **not** cite these numbers as paper-reported results.
