# Hasil Eksperimen AETG

## Ringkasan
- **Random (Baseline)**: Success rate = 100% (1000/1000)
- **LinUCB (Adaptive)**: Success rate = 96.8% (968/1000)
- **Selisih**: Random lebih tinggi 3.2%, tetapi LinUCB menunjukkan adaptasi strategi (5 strategi unik digunakan)

## Interpretasi
- LinUCB mampu mengeksplorasi 5 strategi berbeda, menunjukkan kemampuan adaptasi.
- Random hanya menggunakan 1 strategi (JA3/J4 acak) — efektif, tetapi tidak belajar.
- ESM = 0.000 karena tidak ada data benign untuk perbandingan (perlu ditambahkan di eksperimen lanjutan).
- Feedback IDS (jika aktif) akan meningkatkan performa LinUCB seiring waktu.

## Rekomendasi
- Strategi terbaik: **LinUCB** (untuk lingkungan adaptif dan non-stasioner)
- Parameter yang perlu di-tuning: context vector, epsilon, jumlah strategi
- Langkah selanjutnya: uji dengan attack type lain (DNS, SSH), tambahkan EXP3 sebagai perbandingan, aktifkan IDS feedback.

## Status
- Eksperimen selesai dijalankan pada: 2026-08-19
- Data mentah: `data/results/*.log`
- Ringkasan: `data/results/summary.csv`
- Laporan ini: `data/results/README.md`

## Catatan reproduksibilitas (penting)
File yang disertakan di sini (`summary.csv`, `exp_linucb.log`) hanya mendukung:
- **96.8%** request berhasil (968/1000) sebagai proksi evasion rate
- **1.000 request** total (bukan "38 rounds")
- **5 strategi unik** dieksplorasi LinUCB
- **ESM = 0.000** karena run mock-server ini **tidak menyertakan data benign** untuk perbandingan, sehingga ESM tidak dapat dihitung sebagai stealth score terhadap CICIDS2017

Angka **ESM = 0.14** dan **"38 rounds"** yang muncul di naskah paper berasal dari analisis CICIDS2017-baseline terpisah yang **raw artifact-nya tidak disertakan** dalam submission ini. Oleh karena itu nilai tersebut **tidak dapat direproduksi** dari data yang di-commit dan harus diperlakukan sebagai hasil analisis sebelumnya, bukan output dari log ini.
