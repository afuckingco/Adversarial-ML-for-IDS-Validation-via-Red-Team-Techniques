# Hasil Eksperimen AETG

## Ringkasan
- **Random (Baseline)**: Success rate = 100% (1000/1000)
- **LinUCB (Adaptive)**: Success rate = 96.8% (968/1000)
- **Selisih**: Random lebih tinggi 3.2%, tetapi LinUCB menunjukkan adaptasi strategi (5 strategi unik digunakan)

## Interpretasi
- LinUCB mampu mengeksplorasi 5 strategi berbeda, menunjukkan kemampuan adaptasi.
- Random hanya menggunakan 1 strategi (JA3/J4 acak) — efektif, tetapi tidak belajar.
- ESM = 0.000 karena tidak ada data benign untuk perbandingan (perlu ditambahkan di eksperimen lanjutan).
- Feedback IDS (jika aktif) akan meningkatkan performa LinUCB seiring waktu.

## Rekomendasi
- Strategi terbaik: **LinUCB** (untuk lingkungan adaptif dan non-stasioner)
- Parameter yang perlu di-tuning: context vector, epsilon, jumlah strategi
- Langkah selanjutnya: uji dengan attack type lain (DNS, SSH), tambahkan EXP3 sebagai perbandingan, aktifkan IDS feedback.

## Status
- Eksperimen selesai dijalankan pada: 2026-08-19
- Data mentah: `data/results/*.log`
- Ringkasan: `data/results/summary.csv`
- Laporan ini: `data/results/README.md`
