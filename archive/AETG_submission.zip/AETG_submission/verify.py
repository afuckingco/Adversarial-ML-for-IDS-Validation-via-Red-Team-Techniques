#!/usr/bin/env python3
"""
Verification script for the Adversarial ML for IDS Validation via Red-Team Techniques repository.
Checks that key files exist and have valid Python syntax (without requiring dependencies).
"""

import os
import sys
import subprocess

def check_file_exists(path):
    """Check if a file exists."""
    if not os.path.exists(path):
        print(f"[FAIL] Missing file: {path}")
        return False
    print(f"[OK] Found file: {path}")
    return True

def check_directory_exists(path):
    """Check if a directory exists."""
    if not os.path.isdir(path):
        print(f"[FAIL] Missing directory: {path}")
        return False
    print(f"[OK] Found directory: {path}")
    return True

def check_python_syntax(file_path):
    """Check Python syntax of a file without executing it."""
    try:
        result = subprocess.run([sys.executable, '-m', 'py_compile', file_path],
                                capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            print(f"[OK] Syntax OK: {file_path}")
            return True
        else:
            print(f"[FAIL] Syntax error in {file_path}:")
            print(result.stdout)
            print(result.stderr)
            return False
    except Exception as e:
        print(f"[FAIL] Failed to check syntax for {file_path}: {e}")
        return False

def main():
    """Run all verification checks."""
    print("=== Verification of Adversarial ML for IDS Validation Repository ===\n")
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    all_passed = True
    
    # Check that we are in the repository root
    if not os.path.exists(os.path.join(base_dir, "README.md")):
        print("[FAIL] Not in the repository root: README.md not found")
        return False
    
    # Tasks live under code/ in this submission layout.
    code_dir = os.path.join(base_dir, "code")
    paper_dir = os.path.join(base_dir, "AETG_paper")

    tasks = {
        "code/adversarial-traffic-generator": [
            "src/traffic_gen.py",
            "src/mab_optimizer.py",
            "src/stealth_metric.py",
            "new_traffic_gen.py",
            "README.md",
            "requirements.txt",
            "tests/test_aetg_integration.py",
        ],
        "code/mini-soc-enterprise-arch": [
            "docker-compose.yml",
            "README.md",
            "ids/Dockerfile",
            "ids/app.py",
            "shared/model/xgb_model.json",
            "shared/model/scaler_params.json",
            "push_alerts.py",
        ],
        "code/experiments": [
            "eval_ids.py",
            "adv_training.py",
            "eval_results.json",
            "adv_training_results.json",
        ],
        "AETG_paper": [
            "manuscript/AETG_paper.tex",
            "manuscript/AETG_paper.docx",
            "manuscript/references.bib",
            "output/AETG_paper.pdf",
            "data/eval_results.json",
            "data/adv_training_results.json",
        ],
    }

    # Check each task's files (task paths are relative to base_dir)
    for task_name, files in tasks.items():
        print(f"\n--- Checking {task_name} ---")
        task_dir = os.path.join(base_dir, task_name)
        if not check_directory_exists(task_dir):
            all_passed = False
            continue
        for file_rel in files:
            file_path = os.path.join(task_dir, file_rel)
            if not check_file_exists(file_path):
                all_passed = False
                continue
            # If it's a Python file, check syntax
            if file_path.endswith('.py'):
                if not check_python_syntax(file_path):
                    all_passed = False
    
    print("\n" + "="*60)
    if all_passed:
        print("✅ ALL CHECKS PASSED")
        print("The repository has been successfully created and verified.")
        return True
    else:
        print("❌ SOME CHECKS FAILED")
        print("Please review the error messages above.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)